/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package general;

/**
 *
 * @author maria
 */
import java.util.Scanner;

public class Lectura {
    Scanner sc = new Scanner(System.in);
   
    public String leerString(String mensaje){
        System.out.println(mensaje);
        String dato = sc.nextLine();
        return dato;
    }
    public String leerString2(String mensaje){
        System.out.println(mensaje);
        String dato = sc.next();
        sc.nextLine();
        return dato;
    }
    public int leeryValidarInt(String mensaje) {
        int dato;
        do {
            System.out.print(mensaje);
            while (!sc.hasNextInt()) {
                System.out.println("Valor no v�lido. Intente nuevamente: ");
                sc.nextLine();
            }
            dato = sc.nextInt();
            if(dato < 0){
                System.out.println("El n�mero debe ser positivo");
            }
        } while (dato < 0);
        return dato;
    }
    
    public int leeryValidarInt2(String mensaje, int min, int max) {
    int dato;
    do {
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.println("Valor no v�lido. Intente nuevamente: ");
            sc.next();
        }
        dato = sc.nextInt();
        if (dato < min || dato > max) {
            System.out.println("Por favor, ingrese un n�mero entre " + min + " y " + max + ".");
        }
    } while (dato < min || dato > max);
    return dato;
}
    
    public char leerChar(String mensaje) {
        char caracter;
        do{
            System.out.print(mensaje);
            caracter = sc.next().charAt(0);
            
            while(!validarChar(caracter)){
            System.out.println("Valor no v�lido. Intente nuevamente: ");
            caracter = sc.next().charAt(0);
            }
            sc.nextLine();
            
        }while(!validarChar(caracter));
       
        return caracter;
    }
    
    public boolean validarChar(char caracter){
        if (caracter == 's' || caracter == 'S'){
            return true;
        }
        if (caracter == 'n' || caracter == 'N'){
            return true;
        }
        else{
            return false;
        }
    }
}

