/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU1Registro;

import general.Lectura;
import general.Persona;
import java.util.*;

/**
 *
 * @author maria
 */
public class Registro {
    Lectura lectura = new Lectura();
    Huesped huesped = new Huesped();
    Grupo grupo = new Grupo();
    static Map<String, String> registrados = new HashMap<>();
          
    public void registrarDatos(){
        char a�adir;
        do{
        huesped.setName(lectura.leerString("Nombre completo del cliente: "));
        huesped.setId(lectura.leerString("Ingrese el n�mero de identificaci�n: "));
        huesped.setCelular(lectura.leeryValidarInt("Ingrese n�mero de celular: "));
        huesped.setEmail(lectura.leerString2("Ingrese el email del cliente:"));
        
        registrados.put(huesped.getId(),huesped.getName());
        
        
        a�adir = lectura.leerChar("Desea a�adir otro cliente? (s/n): ");
        }while(a�adir == 's');
    }
      
    public void registrarDatos1(){
        grupo.ingresarPersona();
        Iterator<Persona> it= grupo.getGrupo().iterator();
        while(it.hasNext()) {
            Persona p = it.next();
        registrados.put(p.getId(), p.getName());
        }        
    }

    public static Map getRegistrados() {
        return registrados;
    }

    public Huesped getHuesped() {
        return huesped;
    }
    
}
