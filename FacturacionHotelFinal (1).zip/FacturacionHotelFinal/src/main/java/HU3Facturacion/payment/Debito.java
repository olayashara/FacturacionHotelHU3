/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion.payment;

/**
 *
 * @author maria
 */
public class Debito extends Tarjeta{
    @Override
    public void printReceipt(double costoTotal) {
        System.out.println("Pago realizado con �xito en Hotel los Roncones \nValor pagado: " + 
                costoTotal);
    }
}
