/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion.payment;

import general.Lectura;

/**
 *
 * @author maria
 */
public class Credito extends Tarjeta {
    static Lectura lectura = new Lectura();
    int nroCuotas;
    double valorCuota1;
    
    public void nroCuotas(double montoCompra){
        nroCuotas = lectura.leeryValidarInt2("N�mero de cuotas: ",1,36);
        if (nroCuotas == 1){
            valorCuota1 = montoCompra;
        }else {
        double amortizacion = montoCompra / nroCuotas;
            valorCuota1 = (montoCompra * 0.03) + amortizacion; 
        }
        
        System.out.println("Valor a pagar: " + montoCompra + " en " + nroCuotas + 
                " cuota(s) de " + valorCuota1 );
    }
    
    public void verificarPago() {
        double saldo = lectura.leeryValidarInt("Saldo disponible: ");
            
        if (saldo < valorCuota1){
            System.out.println("Saldo insuficiente");
            paid = false;
        } else{
        } 
    }
    
    @Override
    public void printReceipt(double costoTotal) {
        System.out.println("Pago realizado con �xito en Hotel los roncones\nValor pagado: "+ valorCuota1 + 
                "\nValor total por pagar: " + costoTotal +
                "\nN�mero de cuotas: " + nroCuotas); 
    }
    
}
