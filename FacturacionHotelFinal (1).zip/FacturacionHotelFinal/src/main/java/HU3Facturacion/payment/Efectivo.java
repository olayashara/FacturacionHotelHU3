/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion.payment;

import general.Lectura;

/**
 *
 * @author maria
 */
public class Efectivo implements Payment {
    static Lectura lectura = new Lectura();
    private double dineroRecibido;
    public boolean paid = true;

    @Override
    public void pay() {
        dineroRecibido = lectura.leeryValidarInt("Dinero recibido en efectivo: ");
    }

    @Override
    public void printReceipt(double costoTotal) {
            System.out.println("Dinero recibido: "+ dineroRecibido + 
                "\n Cambio: " + (dineroRecibido - costoTotal));
    }

    @Override
    public void verificarPago(double costoTotal) {
        if (dineroRecibido < costoTotal){
            System.out.println("Dinero insuficiente. Tr�mite cancelado");
            paid = false;
        }else{
        }
    }
    
    public boolean isPaid() {
        return paid;
    }
}
