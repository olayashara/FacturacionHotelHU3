/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion;

/**
 *
 * @author maria
 */
public class Robos {
    private boolean huboRobos;
    private double costoRobos;

    public Robos() {
        this.huboRobos = false;
        this.costoRobos = 0.0;
    }

    public void registrarRobos(boolean huboRobos, double costoRobos) {
        this.huboRobos = huboRobos;
        if (huboRobos) {
            this.costoRobos = costoRobos;
        } else {
            this.costoRobos = 0.0;
        }
    }

    public boolean isHuboRobos() {
        return huboRobos;
    }

    public double getCostoRobos() {
        return costoRobos;
    }
}