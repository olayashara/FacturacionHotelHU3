/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion;

import HU3Facturacion.payment.Payment;
import general.Persona;
import java.util.ArrayList;

/**
 *
 * @author maria
 */
public class FacturacionGrupal extends Facturacion{
    Bill facturaG = new Bill();  
    int nroHabitaciones;
    ArrayList<Room> habitaciones = new ArrayList<>();
    
    
    @Override
    public void recopilacionDatos() {
        facturaG.setBillNo((int) (Math.random() * 100000));
        
        nroHabitaciones = lectura.leeryValidarInt("�Cu�ntas habitaciones fueron ocupadas por las personas del grupo?: ");
        for (int i = 0; i < nroHabitaciones; i++){
            Room h1 = new Room();
            h1.setNroHabitacion(lectura.leeryValidarInt2("Ingrese el n�mero de habitaci�n ocupada: ", 100, 499));
            h1.setTiempo(lectura.leeryValidarInt("Ingrese el tiempo de estad��a en noches: "));
            int precio = calcularPrecioRoom(h1);
            h1.setPrecio(precio*h1.getTiempo());
            
            habitaciones.add(h1);
        }
        super.incidentes();
        preguntar = lectura.leerChar("�Hizo uso del servicio de lavander�a? (s/n): ");
        super.cobrarLavanderia();
        calcularSubtotal();
         }
    
    public int calcularPrecioRoom(Room h){
        int s1 = (h.getNroHabitacion() / 100);
        return switch (s1) {
            case 1 -> 150000; // habitaci�n individual
            case 2 -> 230000; // habitaci�n doble
            case 3 -> 340000; // habitaci�n familiar
            case 4 -> 500000; // habitaci�n suite
            default -> 0;
        };
    }
    
    @Override
    public void calcularSubtotal(){
        int costoHabitaciones = 0;
        
        for(int i = 0; i < nroHabitaciones; i++){
            costoHabitaciones += habitaciones.get(i).getPrecio();
        }
        
        costoTotal = costoHabitaciones +lavanderia1.getTotalLavanderia() 
                + incidentes.calcularCostoTotalIncidentes() + robos.getCostoRobos();
        imprimir("---------------------------");
        imprimir("Subtotal: " + costoTotal);
        imprimir("---------------------------");
        
    }
    
    @Override
    public void imprimirFactura(Payment payment){
        String idPersona = lectura.leerString("Ingrese el documento de la persona que va a pagar: ");
        String name = (String) (registrados.get(idPersona));
        Persona p = new Persona(name, idPersona);
        facturaG.setPersona(p);
        
        imprimir("--------------------------------------------------------------------------------");
        imprimir("""
                 HOTEL LOS RONCONES SAS
                 NIT: 099856412""");
        imprimir("--------------------------------------------------------------------------------");
        imprimir(facturaG.toString2(p));
        
         for(int i = 0; i < nroHabitaciones; i++){
            imprimir(habitaciones.get(i).toString());
        }

        imprimir(lavanderia1.toString());
        incidentesyRobos();
        
        imprimir("Costo total a pagar: "+ costoTotal);
        payment.printReceipt(costoTotal);
        imprimir("--------------------------------------------------------------------------------");
    }
 }


