/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion;

import HU1Registro.Huesped;
import HU1Registro.Registro;
import HU3Facturacion.payment.Payment;
import general.Lectura;
import java.util.Map;

/**
 *
 * @author maria
 */
public class Facturacion {
    Lectura lectura = new Lectura();
    static int preguntar;
    
    Room habitacion = new Room();
    Bill factura = new Bill();      
    Robos robos = new Robos();
    Incidentes incidentes = new Incidentes();
    Lavanderia lavanderia1 = new Lavanderia();
    Registro registro = new Registro();
    Huesped huesped = new Huesped();
    
    static Map registrados = Registro.getRegistrados();
    
    double costoTotal;
    
    public boolean clienteExistente(){
        String id;
        Object name;
        id = lectura.leerString("Ingrese el n�mero de documento: ");
        name = registrados.get(id);
        if (name != null){
            huesped.setId(id);
            huesped.setName((String) name);
            return true;
        } else {
            return false;
        }
    }

    public void recopilacionDatos() {
        factura.setBillNo((int) (Math.random() * 100000));
        factura.setHuesped(huesped);
        habitacion.setNroHabitacion(lectura.leeryValidarInt2("Ingrese el n�mero de la habitaci�n ocupada: ", 100, 499));
        habitacion.setTiempo(lectura.leeryValidarInt("Ingrese el tiempo de estad��a en noches: "));
        incidentes();
        
        int precio = calcularPrecioRoom();
        habitacion.setPrecio(precio*habitacion.getTiempo());
        preguntar = lectura.leerChar("�Hizo uso del servicio de lavander�a? (s/n): ");
        cobrarLavanderia();
        calcularSubtotal();
         
}
    public void incidentes(){
        char respuestaRobos = lectura.leerChar("�Hubo robos durante la estancia? (s/n): ");
        if (respuestaRobos == 's' || respuestaRobos == 'S') {
            int costoRobos = lectura.leeryValidarInt("Ingrese el costo de los robos: ");
            robos.registrarRobos(true, costoRobos);
        }
        
        char respuestaIncidentes = lectura.leerChar("�Hubo incidentes durante la estancia? (s/n): ");
        if (respuestaIncidentes == 's' || respuestaIncidentes == 'S') {
            agregarIncidentes(incidentes);
        }
    }
    
    public void cobrarLavanderia(){
        if(preguntar == 's'){
            lavanderia1.setNumeroLavadas(lectura.leeryValidarInt("Ingrese el numero de veces que uso el servicio: "));
            lavanderia1.setTotalLavanderia(lavanderia1.getNumeroLavadas() * lavanderia1.getPrecioServicio());
        }
        
    }
    
   private void agregarIncidentes(Incidentes incidentes) {
    int tipoIncidente;
    char calcularMas;
    do {
        tipoIncidente = lectura.leeryValidarInt2("""
                                                 Ingrese el tipo de incidente: 
                                                    (1) para da�o leve, 
                                                    (2) para da�o moderado, 
                                                    (3) para da�o severo, 
                                                 """, 1, 3);
        int costoIncidente = 0;
        switch (tipoIncidente) {
            case 1 -> costoIncidente = 30000; // Da�o leve
            case 2 -> costoIncidente = 40000; // Da�o moderado
            case 3 -> costoIncidente = 60000; // Da�o severo
            default -> {
            }
        }
        
        if (tipoIncidente >= 1 && tipoIncidente <= 3) {
            incidentes.agregarIncidente(tipoIncidente, costoIncidente);
            System.out.println("Da�o registrado con �xito.");
        }
        
        calcularMas = lectura.leerChar("�Desea registrar otro incidente? (s/n): ");
        
    } while (calcularMas == 's' || calcularMas == 'S');
}

    public int calcularPrecioRoom(){
        int s1 = (habitacion.getNroHabitacion() / 100);
        return switch (s1) {
            case 1 -> 150000; // habitaci�n individual
            case 2 -> 230000; // habitaci�n doble
            case 3 -> 340000; // habitaci�n familiar
            case 4 -> 500000; // habitaci�n suite
            default -> 0;
        };
    }
    
    public void incidentesyRobos(){
        if (incidentes.calcularCostoTotalIncidentes() != 0){
            imprimir("Valor a pagar por incidentes ocasionados: " 
                    + incidentes.calcularCostoTotalIncidentes());
        }
        if (robos.getCostoRobos() != 0){
            imprimir("Valor a pagar por robos: " + robos.getCostoRobos());
        }
    }
    
    public void calcularSubtotal(){
        costoTotal = habitacion.getPrecio()+lavanderia1.getTotalLavanderia() 
                + incidentes.calcularCostoTotalIncidentes() + robos.getCostoRobos();
        imprimir("---------------------------");
        imprimir("Subtotal: " + costoTotal);
        imprimir("---------------------------");
    }
    
    public void verificarPago(Payment payment){
       payment.verificarPago(costoTotal);
    }
    
    public void imprimirFactura(Payment payment){
        imprimir("--------------------------------------------------------------------------------");
        imprimir("""
                 HOTEL LOS RONCONES SAS
                 NIT: 099856412""");
        imprimir("--------------------------------------------------------------------------------");
        imprimir(factura.toString());
        imprimir(habitacion.toString());
        imprimir(lavanderia1.toString());
        incidentesyRobos();
        
        imprimir("Costo total a pagar: "+ costoTotal);
        payment.printReceipt(costoTotal);
        imprimir("--------------------------------------------------------------------------------");
    }
    
    public void imprimir(String cadena){
        System.out.println(cadena);
    }
    
    public void payBill(Payment payment){
        payment.pay();
    }

    public double getCostoTotal() {
        return costoTotal;
    }
    
    
}
